from django.shortcuts import render, redirect
from . models import *
from django.contrib import messages
import bcrypt
import re

def index(request):
    return render(request, 'auth/index.html')


def register(request):
    # Create a user object

    if request.method == "POST":
        errors = User.objects.basic_validator(request.POST)
        print(errors)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/authen/register')
        password = request.POST['pw']
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(15)).decode()
        new_user = User.objects.create(
            first_name=request.POST['fname'], last_name=request.POST['lname'], email=request.POST['email'], password=pw_hash)
        request.session['user'] = new_user.first_name
        request.session['id'] = new_user.id
    return render(request, 'visuals/index.html')


def login(request):
    print(request.POST)
    # retrieving a user from the db
    if request.method == "POST":
        logged_user = User.objects.filter(email=request.POST['email'])
        if len(logged_user) > 0:
            logged_user = logged_user[0]
            if bcrypt.checkpw(request.POST['pw'].encode(), logged_user.password.encode()):
                request.session['user'] = logged_user.first_name
                request.session['id'] = logged_user.id
                return redirect('/')
            else:
                messages.error(
                    request, {"err": "Invalid email/password combination"})
                return redirect('/authen/register')

    return render(request, 'index.html')

def logout(request):
    request.session.flush()
    return redirect('/')