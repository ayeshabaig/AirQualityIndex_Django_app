from django.urls import path

from . import views

urlpatterns = [
    path("simple_train", views.simple_train, name = 'simple_train'),
    path("train_csv", views.train_csv, name = 'train_csv'),
    path("simple_test", views.simple_test, name = 'simple_test'),
    path("test_csv", views.test_csv, name = 'test_csv'),
    path("train_data", views.train_data, name = 'train_data'),
    path("test_data", views.test_data, name = 'test_data')
]