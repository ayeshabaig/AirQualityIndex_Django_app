from django.shortcuts import render
from authen.models import User
from django.contrib import messages
import pandas as pd
import numpy as np
from time import time
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error
import pickle

def simple_train(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    return render(request, "models/simple_train.html")


def simple_test(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    return render(request, "models/simple_test.html")



def train(train_df):
    cols = ["Wind-Dir", 'cos_wind', 'TEMP', 'sin_wind','population', 'VIS']
    X_train = train_df[cols]
    y_train = train_df['AQI_VALUE']
    model = DecisionTreeRegressor(criterion='mse', max_depth=None, max_features=None,
                       max_leaf_nodes=None, min_impurity_decrease=0.0,
                       min_impurity_split=None, min_samples_leaf=3,
                       min_samples_split=2, min_weight_fraction_leaf=0.0,
                       presort=False, random_state=None, splitter='best')
    
    t1 = time()
    model.fit(X_train, y_train)
    t2 = time()
    score = model.score(X_train, y_train)
    results = []
    result = [
        f"time taken to train (sec) : {t2-t1}",
        f"training model score:  {score}"
    ]

    model.fit(X_train, y_train)
    filename = 'model.sav'
    pickle.dump(model, open(filename, 'wb'))
    train_df.to_csv("train_data.csv", index=False)
    return result

def test(test_df):
    filename = 'model.sav'
    loaded_model = pickle.load(open(filename, 'rb'))
    
    cols = ["Wind-Dir", 'cos_wind', 'TEMP', 'sin_wind','population', 'VIS']
    X_test = test_df[cols]
    y_test = test_df['AQI_VALUE']
    
    t1 = time()
    y_pred = loaded_model.predict(X_test)
    t2 = time()
    score = loaded_model.score(X_test, y_test)
    rmse = mean_squared_error(y_pred=y_pred, y_true=y_test)
    avg_diff = (y_test - y_pred).mean()
    result = [f"time taken to test (sec) : {t2-t1}"  , f"score for testing model :  {score}", f"mean square error of testing : {rmse}", f"avg result deviation : {avg_diff}"]
    return result



def train_data(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    if request.method == "POST":
        train_df = pd.read_csv('train_data.csv')
        wind_dir  = float(request.POST["wind_dir"])
        cos_wind  = float(request.POST["cos_wind"])
        TEMP  = float(request.POST["TEMP"])
        sin_wind  = float(request.POST["sin_wind"])
        population  = float(request.POST["population"])
        VIS  = float(request.POST["VIS"])
        AQI_VALUE  = float(request.POST["AQI_VALUE"])
        data_df = pd.DataFrame({'Wind-Dir' : [wind_dir],
                            "AQI_VALUE" : [AQI_VALUE],
                            "cos_wind": [cos_wind],
                            "TEMP": [TEMP],
                            "sin_wind": [sin_wind],
                            "population":[population],
                            "VIS": [VIS]})
        new_df = pd.concat([train_df, data_df])
        print(new_df.shape)
        dp_count = 1
        results = train(new_df)
        results.append(f"no of values stored in new training file : {len(new_df)}")
        context = {
            "results": results
        } 
        
        return render(request, "models/simple_train.html", context)



def test_data(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    if request.method == "POST":
        train_df = pd.read_csv('train_data.csv')
        wind_dir  = float(request.POST["wind_dir"])
        cos_wind  = float(request.POST["cos_wind"])
        TEMP  = float(request.POST["TEMP"])
        sin_wind  = float(request.POST["sin_wind"])
        population  = float(request.POST["population"])
        VIS  = float(request.POST["VIS"])
        AQI_VALUE  = float(request.POST["AQI_VALUE"])
        data_df = pd.DataFrame({'Wind-Dir' : [wind_dir],
                            "AQI_VALUE" : [AQI_VALUE],
                            "cos_wind": [cos_wind],
                            "TEMP": [TEMP],
                            "sin_wind": [sin_wind],
                            "population":[population],
                            "VIS": [VIS]})
        new_df = pd.concat([train_df, data_df])
        print(new_df.shape)
        dp_count = 1
        results = test(new_df)
        results.append(f"no of trained data points : {dp_count}")
        context = {
            "results": results
        } 
        
        return render(request, "models/simple_train.html", context)

def train_csv(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    if request.method == "POST":
        upload_df = pd.read_csv(request.FILES['csv_file'])
        df = pd.read_csv("train_data.csv")
        new_df = pd.concat([df, upload_df])
        df_count = len(upload_df)
        results = test(new_df)
        results.append(f"no of trained data points : {df_count}")
        context = {
            "results": results,
        }
        return render(request, "models/simple_train.html", context=context)

def test_csv(request): 
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    if request.method == "POST":
        upload_df = pd.read_csv(request.FILES['csv_file'])
        results = test(upload_df)
        df_count = len(upload_df)
        results.append(f"no of trained data points : {df_count}")
        context = {
            "results": results,
        }
        return render(request, "models/simple_test.html", context=context)