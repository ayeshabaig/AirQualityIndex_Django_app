from django.apps import AppConfig


class VisualsConfig(AppConfig):
    name = 'visuals'
