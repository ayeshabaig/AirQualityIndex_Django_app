from django.shortcuts import render
from authen.models import User
from django.contrib import messages
import pandas as pd


train_df = pd.read_csv("train_data.csv")
test_df = pd.read_csv("test_data.csv")

# Create your views here.
def index(request):
    try:
        user = User.objects.get(id=request.session['id'])
    except:
        messages.error(
            request, {"unauthorized": "Please log in first to view your app content"})
        return render(request, 'auth/index.html')
    

    temp = train_df.describe()
    cols = str(list(temp.columns)).replace(" ", "")
    print(cols)
    mean = ",".join(map(str,list(temp.loc["mean", :])))
    std = ",".join(map(str,list(temp.loc["std", :])))
    minimum = ",".join(map(str,list(temp.loc["min", :])))
    precentile25 = ",".join(map(str,list(temp.loc["25%", :])))
    percentile75 = ",".join(map(str,list(temp.loc["75%", :])))
    maximum = ",".join(map(str,list(temp.loc["max", :])))

    context = {
        "columns" : cols,
        "mean" : mean,
        "std": std,
        "min": minimum,
        "25%": precentile25,
        "75%": percentile75,
        "max": maximum,
    }
    print(context)
    return render(request, "visuals/index.html", context)